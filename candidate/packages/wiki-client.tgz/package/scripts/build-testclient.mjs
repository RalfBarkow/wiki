import * as esbuild from 'esbuild'
import { existsSync, readFileSync } from 'node:fs'
import packJSON from '../package.json' with { type: 'json' }

const version = packJSON.version
const now = new Date(Number(process.env.SOURCE_DATE_EPOCH || 1) * 1000)
const gitSha = process.env.WIKI_CLIENT_REV || (() => {
  try {
    const head = readFileSync('.git/HEAD', 'utf8').trim()
    if (!head.startsWith('ref: ')) return head.slice(0, 7)
    const ref = head.slice(5)
    const refPath = `.git/${ref}`
    if (existsSync(refPath)) return readFileSync(refPath, 'utf8').trim().slice(0, 7)
    const packedRefs = '.git/packed-refs'
    if (existsSync(packedRefs)) {
      const lines = readFileSync(packedRefs, 'utf8').split('\n')
      for (const line of lines) {
        if (line.startsWith('#') || line.startsWith('^') || !line.trim()) continue
        const [sha, name] = line.trim().split(' ')
        if (name === ref) return sha.slice(0, 7)
      }
    }
  } catch {
    return 'unknown'
  }
  return 'unknown'
})()
const stampedVersion = `${version}-dev+${gitSha}`

await esbuild.build({
  entryPoints: ['testclient.js'],
  bundle: true,
  banner: {
    js: `/* wiki-client (test) - ${stampedVersion} - ${now.toUTCString()} */`,
  },
  minify: true,
  sourcemap: true,
  logLevel: 'info',
  outfile: 'client/test/testclient.js',
})
